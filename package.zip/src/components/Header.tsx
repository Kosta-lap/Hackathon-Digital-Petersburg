import React, { useState, useEffect } from 'react';

const Header: React.FC = () => {
  const [isSticky, setIsSticky] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 100) {
        setIsSticky(true);
      } else {
        setIsSticky(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, []);

  return (
    <header className={isSticky ? 'sticky' : ''}>
      <div className="container">
        <div className="header_box">
          <h2 className="logo">логотип</h2>
          <nav className="header_nav">
            <button type="button">Начать</button>
            <button type="button">Войти</button>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;