import React from 'react';
import Header from "../components/Header"
import Footer from "./Footer";

import event from "../images/event.jpg"

const SearchPage: React.FC = () => {
    return (
        <div className="main main_lk">
            <Header />
            <section className="lk events">
                <div>
                    <div className="container">
                        <div className="lk-content">
                            <div className="search_form">
                                <div className="input_box">
                                    <h4>Цена</h4>
                                    <div className="inputs_check">
                                        <div className="check_box">
                                            <label htmlFor="free">Бесплатно</label>
                                            <input type="radio" id="free" name="priceType" />
                                        </div>
                                        <div className="check_box">
                                            <label htmlFor="paid">Платно</label>
                                            <input type="radio" id="paid" name="priceType" />
                                        </div>
                                        <div className="check_box">
                                            <label htmlFor="fip">Платно и бесплатно</label>
                                            <input type="radio" id="fip" name="priceType" />
                                        </div>
                                    </div>
                                </div>
                                <div className="input_box">
                                    <h4>Местоположение</h4>
                                    <div className="text_box">
                                        <label htmlFor="count_m">Не более <input type="text" id="count_m" className='reg-log-form__input' /> минут</label>
                                    </div>
                                </div>
                                <div className="input_box">
                                    <h4>Время</h4>
                                    <div className="text_box time">
                                        <label htmlFor="count_t_ot">от <input type="text" id="count_t_ot" className='reg-log-form__input' /></label>
                                        <label htmlFor="count_t_do">до <input type="text" id="count_t_do" className='reg-log-form__input' /></label>
                                    </div>
                                </div>
                                <div className="input_box">
                                    <h4>Категории</h4>
                                    <div className="category_box">
                                        <button className="category-btn about" data-category="quests">Квесты</button>
                                        <button className="category-btn about" data-category="quests">Выставки</button>
                                        <button className="category-btn about" data-category="quests">События для бизнеса</button>
                                        <button className="category-btn about" data-category="quests">Кинопоказы</button>
                                        <button className="category-btn about" data-category="quests">Концерты</button>
                                        <button className="category-btn about" data-category="quests">Благотворительность</button>
                                    </div>
                                </div>
                            </div>
                            <div className="search_response">
                                <div className="lk-favorite_card lk-favorite-card">
                                    <img src={event} alt="" className="lk-favorite-card__image" />
                                    <div className="lk-favorite-card__desc">
                                        <h4>Название события</h4>
                                        <div className="lk-favorite-card__about">
                                            <p>Подробное описание события</p>
                                            <p>Место проведения, Время</p>
                                        </div>
                                        <div className="lk-favorite-card__actions">
                                            <button className="about">Подробнее</button>
                                            <button className="like active" />
                                        </div>
                                    </div>
                                </div>
                                <div className="lk-favorite_card lk-favorite-card">
                                    <img src={event} alt="" className="lk-favorite-card__image" />
                                    <div className="lk-favorite-card__desc">
                                        <h4>Название события</h4>
                                        <div className="lk-favorite-card__about">
                                            <p>Подробное описание события</p>
                                            <p>Место проведения, Время</p>
                                        </div>
                                        <div className="lk-favorite-card__actions">
                                            <button className="about">Подробнее</button>
                                            <button className="like active" />
                                        </div>
                                    </div>
                                </div>
                                <div className="lk-favorite_card lk-favorite-card">
                                    <img src={event} alt="" className="lk-favorite-card__image" />
                                    <div className="lk-favorite-card__desc">
                                        <h4>Название события</h4>
                                        <div className="lk-favorite-card__about">
                                            <p>Подробное описание события</p>
                                            <p>Место проведения, Время</p>
                                        </div>
                                        <div className="lk-favorite-card__actions">
                                            <button className="about">Подробнее</button>
                                            <button className="like active" />
                                        </div>
                                    </div>
                                </div>
                                <div className="lk-favorite_card lk-favorite-card">
                                    <img src={event} alt="" className="lk-favorite-card__image" />
                                    <div className="lk-favorite-card__desc">
                                        <h4>Название события</h4>
                                        <div className="lk-favorite-card__about">
                                            <p>Подробное описание события</p>
                                            <p>Место проведения, Время</p>
                                        </div>
                                        <div className="lk-favorite-card__actions">
                                            <button className="about">Подробнее</button>
                                            <button className="like active" />
                                        </div>
                                    </div>
                                </div>
                                <div className="lk-favorite_card lk-favorite-card">
                                    <img src={event} alt="" className="lk-favorite-card__image" />
                                    <div className="lk-favorite-card__desc">
                                        <h4>Название события</h4>
                                        <div className="lk-favorite-card__about">
                                            <p>Подробное описание события</p>
                                            <p>Место проведения, Время</p>
                                        </div>
                                        <div className="lk-favorite-card__actions">
                                            <button className="about">Подробнее</button>
                                            <button className="like active" />
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <Footer />
            </section>

        </div>
    );
};

export default SearchPage;